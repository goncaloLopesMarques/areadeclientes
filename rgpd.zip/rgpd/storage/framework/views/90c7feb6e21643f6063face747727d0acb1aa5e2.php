<!-- Main layout -->
    <main class="mt-5 pt-5">
        <div class="container">

            <!--Section: Jumbotron-->
            <section class="card wow fadeIn" id="intro">

                <!-- Content -->
                <div class="card-body text-white text-center py-5 px-5 my-5">

                    <h1 class="mb-4">
                        <strong>RGPD - Como fazer para o seu website cumprir a nova lei da proteção de dados</strong>
                    </h1>
                    <p>
                        <strong>Como fazer para que o seu website</strong>
                    </p>
                    <p class="mb-4">
                        <strong>The most comprehensive tutorial for the Bootstrap 4. Loved by over 500 000 users. Video and written
                            versions available. Create your own, stunning website.</strong>
                    </p>
                    <a target="_blank" href="https://mdbootstrap.com/bootstrap-tutorial/" class="btn btn-outline-white btn-lg">Start free tutorial
                        <i class="fa fa-graduation-cap ml-2"></i>
                    </a>

                </div>
                <!-- Content -->
            </section>
            <!--Section: Jumbotron-->



            <!--Section: Cards-->
            <section class="pt-5">

                <!-- Heading & Description -->
                <div class="wow fadeIn">
                    <!--Section heading-->
                    <h2 class="h1 text-center mb-5">What is MDB?</h2>
                    <!--Section description-->
                    <p class="text-center">MDB is world's most popular Material Design framework for building responsive, mobile-first websites
                        and apps. </p>
                    <p class="text-center mb-5 pb-5">Trusted by over
                        <strong>400 000</strong> developers and designers. Easy to use & customize. 400+ material UI elements, templates
                        & tutorials.</p>
                </div>
                <!-- Heading & Description -->

                <!--Grid row-->
                <div class="row wow fadeIn">

                    
                    <!-- Default form contact -->
                    <form id="dados-do-cliente">
                        <p class="h4 text-center mb-4">Write to us</p>

                        <!-- Default input name -->
                        <label for="defaultFormContactNameEx" class="grey-text">Nome</label>
                        <input type="text" id="defaultFormContactNameEx" class="form-control">
                        
                        <br>

                        <!-- Default input email -->
                        <label for="defaultFormContactEmailEx" class="grey-text">Email</label>
                        <input type="email" id="defaultFormContactEmailEx" class="form-control">

                        <br>

                        <!-- Default input subject -->
                        <label for="defaultFormContactSubjectEx" class="grey-text">Subject</label>
                        <input type="text" id="defaultFormContactSubjectEx" class="form-control">

                        <br>
                        
                        <!-- Default textarea message -->
                        <label for="defaultFormContactMessageEx" class="grey-text">Your message</label>
                        <textarea type="text" id="defaultFormContactMessageEx" class="form-control" rows="3"></textarea>

                        <div class="text-center mt-4">
                            <button class="btn btn-mdb-color waves-effect waves-light" type="submit">Send<i class="fa fa-paper-plane-o ml-2"></i></button>
                        </div>
                    </form>
                    <!-- Default form contact -->
                      

                    <!--Grid column-->
                   
                    <!--Grid column-->

                </div>
                <!--Grid row-->

                <hr class="mb-5">

            </section>
            <!--Section: Cards-->

        </div>
    </main>