<?php $__env->startSection('content'); ?>
<script>
  function fillHiddenInputs(){
       var idCrm = document.getElementById('idCrm')
       var emailCrm = document.getElementById('emailCrm')
       var url = new URL(window.location.href);
       if(url.searchParams.get("id")){
        idCrm.value = url.searchParams.get("id");
       }else{
           alert("Não existe nenhum id por favor contactar, digitalinput@digitalinput.pt")
       }if(url.searchParams.get("email")){
        emailCrm.value = url.searchParams.get("email");
       }else{
           alert("naão existe nenhum email, contactar digitalinput@digitalinput.pt")
       }
        console.log(idCrm)
        console.log(emailCrm)
    }
</script>
<body onload="fillHiddenInputs();">
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Register</div>
                <a href="http://127.0.0.1/areacliente/rgpd/public/register?id=2c1a8898-3f0e-cb24-2a0e-5aec65edd007&email=example@example.com">Visit W3Schools</a>
                <div class="panel-body">
                    <form class="form-horizontal" method="POST" action="<?php echo e(url('/registration')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <?php if(count($errors)>0): ?>

                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="alert alert-danger"><?php echo e($error); ?></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-4 control-label">Name</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autofocus>
                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label for="password" class="col-md-4 control-label">Password</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="password-confirm" class="col-md-4 control-label">Confirm Password</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                        </div>
                        <input type="hidden" name ="idCrm" id="idCrm" value="123">
                        <input type="hidden" name ="emailCrm" id="emailCrm" value="123@123.com" >

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Register
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>