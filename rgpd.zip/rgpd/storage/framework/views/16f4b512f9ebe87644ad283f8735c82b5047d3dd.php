<?php $__env->startSection('head'); ?>

    <?php echo $__env->make('layout.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
<?php $__env->stopSection(); ?>


<?php $__env->startSection('nav-bar'); ?>

    <?php echo $__env->make('layout.nav-bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
<?php $__env->stopSection(); ?>




<?php $__env->startSection('main'); ?>

    <?php echo $__env->make('layout.conteudo-registo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
<?php $__env->stopSection(); ?>



<?php $__env->startSection('footer'); ?>

    <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts-css'); ?>

    <?php echo $__env->make('layout.scripts-css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
<?php $__env->stopSection(); ?>


<?php $__env->startSection('modals'); ?>

    <?php echo $__env->make('layout.modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
<?php $__env->stopSection(); ?>






<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>