<!DOCTYPE html>
<html lang="pt">

<head>

    <?php echo $__env->yieldContent('head'); ?>

</head>

    <body>

        <!--Main Navigation-->
        <header>

         <?php echo $__env->yieldContent('nav-bar'); ?>

        </header>

        <!-- <main class="mt-5 pt-5"> -->
        <?php echo $__env->yieldContent('main'); ?>
        <!-- </main> -->

        <!-- <footer class="page-footer text-center font-small mdb-color darken-2 mt-4 wow fadeIn"> -->
        <?php echo $__env->yieldContent('footer'); ?>
        <!-- </footer> -->
           
        <?php echo $__env->yieldContent('scripts-css'); ?>
        
        <?php echo $__env->yieldContent('modals'); ?>

    </body>

</html>
